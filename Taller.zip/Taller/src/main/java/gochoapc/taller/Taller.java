/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package gochoapc.taller;

/**
 *
 * @author GOchoa
 */
public class Taller {

    public static void main(String[] args) {
        TallerForm form = new TallerForm();
     form.setVisible(true);
    }
}
